from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from flask_mail import Mail
import json
import os
import math
from datetime import datetime
import MySQLdb
from sqlalchemy import func


with open('config.json', 'r') as c:
    params = json.load(c)["params"]


local_server = True
app = Flask(__name__)

app.secret_key = 'super-secret-key'
app.config['UPLOAD_FOLDER'] = params['upload_location']
app.config.update(
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT='465',
    MAIL_USE_SSL=True,
    MAIL_USERNAME=params['gmail-user'],
    MAIL_PASSWORD=params['gmail-password']
)
mail = Mail(app)
if (local_server):
    app.config['SQLALCHEMY_DATABASE_URI'] = params['local_uri']
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = params['prod_uri']

db = SQLAlchemy(app)




class Posts(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80), nullable=False)
    slug = db.Column(db.String(21), nullable=False)
    content = db.Column(db.String(120), nullable=False)
    tagline = db.Column(db.String(120), nullable=False)
    date = db.Column(db.String(12), nullable=True)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    password = db.Column(db.String(120), nullable=False)

#.......................DOCTOR.............................
class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    specialty = db.Column(db.String(120), nullable=False)
    availability = db.Column(db.String(120), nullable=False)

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), nullable=False)
    user_name = db.Column(db.String(120), nullable=False)
    user_phone = db.Column(db.String(20), nullable=False)
    user_address = db.Column(db.String(255), nullable=False)
    appointment_date = db.Column(db.DateTime, nullable=False)


#........................MEDICINE...............................

class Medicine(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    expired_date = db.Column(db.Date, nullable=False)
    origin = db.Column(db.String(255), nullable=False)
    price = db.Column(db.Float, nullable=False)


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    medicine_id = db.Column(db.Integer, db.ForeignKey(
        'medicine.id'), nullable=False)
    customer_name = db.Column(db.String(255), nullable=False)
    customer_email = db.Column(db.String(255), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    order_date = db.Column(db.Date, nullable=False)
    medicine = db.relationship('Medicine', backref='orders')

# .......................AMBULANCE................................


class AmbulanceOrder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    address = db.Column(db.Text, nullable=False)
    date = db.Column(db.Date, nullable=False)
    ambulance_type = db.Column(db.String(20), nullable=False)

    def __init__(self, name, phone, address, date, ambulance_type):
        self.name = name
        self.phone = phone
        self.address = address
        self.date = date
        self.ambulance_type = ambulance_type





class Room(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    room_number = db.Column(db.String(50), unique=True, nullable=False)
    image_path = db.Column(db.String(255))
    available_from = db.Column(db.DateTime)
    available_to = db.Column(db.DateTime)
    bookings = db.relationship('Booking', backref='room', lazy=True)


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('room.id'))
    booking_date = db.Column(db.DateTime, default=datetime.now())
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    address = db.Column(db.String(255))


@app.route("/")
@app.route("/home")
def home():
    posts = Posts.query.filter_by().all()
    last = math.ceil(len(posts)/int(params['no_of_posts']))
    # [0: params['no_of_posts']]
    # posts = posts[]
    page = request.args.get('page')
    if (not str(page).isnumeric()):
        page = 1
    page = int(page)
    posts = posts[(page-1)*int(params['no_of_posts']): (page-1)
                  * int(params['no_of_posts']) + int(params['no_of_posts'])]
    # Pagination Logic
    # First
    if (page == 1):
        prev = "#"
        next = "/?page=" + str(page+1)
    elif (page == last):
        prev = "/?page=" + str(page - 1)
        next = "#"
    else:
        prev = "/?page=" + str(page - 1)
        next = "/?page=" + str(page + 1)

    return render_template('index.html', params=params, posts=posts, prev=prev, next=next)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Fetch form data
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        # Create a new User instance
        user = User(name=name, email=email, password=password)

        # Add the User to the database
        db.session.add(user)
        db.session.commit()

        return render_template('login.html')

    return render_template('signup.html')


@app.route("/post/<string:post_slug>", methods=['GET'])
def post_route(post_slug):
    post = Posts.query.filter_by(slug=post_slug).first()
    return render_template('post.html', params=params, post=post)


@app.route("/login", methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        name = request.form.get('uname')
        password = request.form.get('pass')

        # Database connect
        conn = MySQLdb.connect(host='localhost', user='root',
                               passwd='', db='codingthunder')
        cursor = conn.cursor()
        # Query execute
        cursor.execute('SELECT * FROM user WHERE  `name` = %s AND `password` = %s ',
                       (name, password))
        # Matched row in 'user'
        user = cursor.fetchone()
        # print(user)
        if user == None:
            return redirect(url_for('login'))
        # elif   user==params['admin_user']:
        #     return redirect('/dashboard')
        #     # return render_template('dashboard.html', params=params, posts = posts)
        else:
            # #modified
            # return redirect(url_for('home'))

            if user[2] == 'team9@gmail.com':
                # return render_template("dashboard.html")
                return redirect(url_for('dashboard'))
            else:
                # return render_template("index.html")

                return redirect(url_for('home'))

    else:
        return render_template('login.html', params=params)


@app.route("/dashboard", methods=['GET', 'POST'])
def dashboard():

    # if ('user' in session and session['user'] == params['admin_user']):
    #     posts = Posts.query.all()
    #     return render_template('dashboard.html', params=params, posts = posts)
    #
    #
    if request.method == 'POST':

        print("hellow")
    #
    #     if (username == params['admin_user'] and userpass == params['admin_password']):
    #         #set the session variable
    #         session['user'] = username
    #         posts = Posts.query.all()
    #         return render_template('dashboard.html', params=params, posts = posts)
    conn = MySQLdb.connect(host='localhost', user='root',
                           passwd='', db='codingthunder')
    cursor = conn.cursor()
    # Query execute
    cursor.execute('SELECT * FROM posts')
    # Matched row in 'user'
    user = cursor.fetchall()
    # print(user)

    return render_template('dashboard.html', user=user)


@app.route("/edit", methods=['GET', 'POST'])
def edit():
    title = request.form.get('title')
    tline = request.form.get('tline')
    slug = request.form.get('slug')
    content = request.form.get('content')

    user = Posts.query.filter_by(slug=slug).first()

    if user:
        user.title = request.form.get('title')
        user.tagline = request.form.get('tline')
        user.slug = request.form.get('slug')
        user.content = request.form.get('content')

        db.session.commit()

    return render_template('edit.html')


@app.route("/uploader", methods=['GET', 'POST'])
def uploader():
    if ('user' in session and session['user'] == params['admin_user']):
        if (request.method == 'POST'):
            f = request.files['file1']
            f.save(os.path.join(
                app.config['UPLOAD_FOLDER'], secure_filename(f.filename)))
            return "Uploaded successfully"


@app.route("/logout")
def logout():
    session.pop('user')
    return redirect('/dashboard')


@app.route("/delete", methods=['GET', 'POST'])
def delete():

    slug = request.form.get('slug')

    user = Posts.query.filter_by(slug=slug).first()
    # print(user)
    if user:
        db.session.delete(user)
        db.session.commit()

    return render_template('delete.html')


@app.route("/add", methods=['GET', 'POST'])
def add():
    if request.method == 'POST':

        title = request.form.get('title')
        tagline = request.form.get('tline')
        slug = request.form.get('slug')
        content = request.form.get('content')

        date = request.form.get('date')

        entry = Posts(title=title, tagline=tagline, slug=slug,
                      content=content,  date=date)
        db.session.add(entry)
        db.session.commit()

    return render_template('add.html')


# ...................................................DOCTORS.....................
@app.route("/doctors", methods=['GET'])
def doctors():
    doctors = Doctor.query.all()
    return render_template('doctors.html', doctors=doctors)


@app.route("/search_doctors", methods=['GET'])
def search_doctors():
    name = request.args.get('name')
    specialty = request.args.get('specialty')
    availability = request.args.get('availability')

    query = Doctor.query

    if name:
        query = query.filter(Doctor.name.like(f"%{name}%"))
    if specialty:
        query = query.filter(Doctor.specialty.like(f"%{specialty}%"))
    if availability:
        query = query.filter(Doctor.availability.like(f"%{availability}%"))

    doctors = query.all()

    return render_template('doctors.html', doctors=doctors)


# ..........................................NEW...................................................
@app.route("/dashboard/doctors", methods=['GET'])
def admin_doctors():
    doctors = Doctor.query.all()
    return render_template('admin_doctors.html', doctors=doctors)


@app.route("/dashboard/add_doctor", methods=['POST'])
def add_doctor():
    name = request.form['name']
    specialty = request.form['specialty']
    availability = request.form['availability']

    new_doctor = Doctor(name=name, specialty=specialty,
                        availability=availability)
    db.session.add(new_doctor)
    db.session.commit()

    flash('Doctor added successfully!', 'success')
    return redirect(url_for('admin_doctors'))


@app.route("/dashboard/edit_doctor/<int:id>", methods=['GET', 'POST'])
def edit_doctor(id):
    doctor = Doctor.query.get_or_404(id)

    if request.method == 'POST':
        doctor.name = request.form['name']
        doctor.specialty = request.form['specialty']
        doctor.availability = request.form['availability']
        db.session.commit()
        flash('Doctor updated successfully!', 'success')
        return redirect(url_for('admin_doctors'))

    return render_template('edit_doctor.html', doctor=doctor)


@app.route("/dashboard/delete_doctor/<int:id>", methods=['GET', 'POST'])
def delete_doctor(id):
    doctor = Doctor.query.get_or_404(id)
    if request.method == 'POST':
        db.session.delete(doctor)
        db.session.commit()
        flash('Doctor deleted successfully!', 'success')
        return redirect(url_for('admin_doctors'))
    return render_template('admin_doctors.html', doctors=[doctor])



@app.route("/make_appointment/<int:doctor_id>", methods=['GET', 'POST'])
def make_appointment(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)

    if request.method == 'POST':
        user_name = request.form['user_name']
        user_phone = request.form['user_phone']
        user_address = request.form['user_address']
        appointment_date = datetime.now()

        new_appointment = Appointment(doctor_id=doctor_id, user_name=user_name, user_phone=user_phone,
                                      user_address=user_address, appointment_date=appointment_date)
        db.session.add(new_appointment)
        db.session.commit()

        flash('Appointment made successfully!', 'success')
        return redirect(url_for('doctors'))

    return render_template('make_appointment.html', doctor=doctor)





@app.route("/dashboard/view_appointments/<int:doctor_id>", methods=['GET'])
def view_appointments(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)

    max_appointments = 10
    booked_appointments = Appointment.query.filter_by(doctor_id=doctor_id).count()
    available_slots = max_appointments - booked_appointments

    appointments = Appointment.query.filter_by(doctor_id=doctor_id).all()

    return render_template('view_appointments.html', doctor=doctor, appointments=appointments,
                           available_slots=available_slots)


# ..............................Medicine Part(ADD,DELETE,Modify)..................
@app.route("/medicines", methods=['GET'])
def medicines():
    medicines = Medicine.query.all()
    return render_template('medicines.html', medicines=medicines)


@app.route("/search_medicines", methods=['GET'])
def search_medicines():
    name = request.args.get('name')
    origin = request.args.get('origin')
    price = request.args.get('price')

    query = Medicine.query

    if name:
        query = query.filter(Medicine.name.like(f"%{name}%"))
    if origin:
        query = query.filter(Medicine.origin.like(f"%{origin}%"))
    if price:
        query = query.filter(Medicine.price == float(price))

    medicines = query.all()

    return render_template('medicines.html', medicines=medicines)


@app.route("/add_medicine", methods=['GET', 'POST'])
def add_medicine():
    if request.method == 'POST':
        name = request.form['name']
        expired_date = datetime.strptime(
            request.form['expired_date'], '%Y-%m-%d').date()
        origin = request.form['origin']
        price = float(request.form['price'])

        new_medicine = Medicine(name=name, expired_date=expired_date,
                                origin=origin, price=price)
        db.session.add(new_medicine)
        db.session.commit()

        flash('Medicine added successfully!', 'success')
        return redirect(url_for('medicines'))

    return render_template('add_medicine.html')


@app.route("/edit_medicine/<int:id>", methods=['GET', 'POST'])
def edit_medicine(id):
    medicine = Medicine.query.get_or_404(id)

    if request.method == 'POST':
        medicine.name = request.form['name']
        medicine.expired_date = datetime.strptime(
            request.form['expired_date'], '%Y-%m-%d').date()
        medicine.origin = request.form['origin']
        medicine.price = float(request.form['price'])
        db.session.commit()

        flash('Medicine updated successfully!', 'success')
        return redirect(url_for('medicines'))

    return render_template('edit_medicine.html', medicine=medicine)


@app.route("/delete_medicine/<int:id>", methods=['POST'])
def delete_medicine(id):
    medicine = Medicine.query.get_or_404(id)
    db.session.delete(medicine)
    db.session.commit()

    flash('Medicine deleted successfully!', 'success')
    return redirect(url_for('medicines'))


# .......................MEDICINE ORDERS..................................
@app.route("/medicines_order", methods=['GET'])
def medicines_order():
    medicines = Medicine.query.all()
    return render_template('medicine_user.html', medicines=medicines)


@app.route("/order/<int:medicine_id>", methods=['GET', 'POST'])
def order(medicine_id):
    medicine = Medicine.query.get_or_404(medicine_id)

    if request.method == 'POST':
        customer_name = request.form['customer_name']
        customer_email = request.form['customer_email']
        quantity = int(request.form['quantity'])
        order_date = datetime.now().date()

        new_order = Order(medicine=medicine, customer_name=customer_name,
                          customer_email=customer_email, quantity=quantity, order_date=order_date)
        db.session.add(new_order)
        db.session.commit()

        flash('Order placed successfully!', 'success')
        return redirect(url_for('medicines_order'))

    return render_template('order.html', medicine=medicine)


@app.route("/manage_orders", methods=['GET'])
def manage_orders():
    orders = Order.query.all()
    return render_template('manage_orders.html', orders=orders)


@app.route("/delete_order/<int:id>", methods=['POST'])
def delete_order(id):
    order = Order.query.get_or_404(id)
    db.session.delete(order)
    db.session.commit()

    flash('Order deleted successfully!', 'success')
    return redirect(url_for('manage_orders'))


# ..........................................ROOMS AVAILABLE.............................................................
# User End
@app.route('/user_rooms')
def user_end():
    rooms = Room.query.all()
    return render_template('user_rooms.html', rooms=rooms)


@app.route('/book', methods=['POST'])
def book_room():
    room_id = request.form.get('room_id')
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    address = request.form.get('address')

    booking = Booking(room_id=room_id, name=name,
                      email=email, phone=phone, address=address)
    db.session.add(booking)
    db.session.commit()

    return redirect(url_for('user_end'))

# Admin End


@app.route('/rooms')
def admin_end():
    rooms = Room.query.all()
    return render_template('rooms.html', rooms=rooms)


@app.route('/add_room', methods=['POST'])
def add_room():
    room_number = request.form.get('room_number')
    available_from = request.form.get('available_from')
    available_to = request.form.get('available_to')

    image = request.files['image']
    filename = secure_filename(image.filename)
    image.save(os.path.join('static', filename))

    new_room = Room(room_number=room_number, image_path=filename,
                    available_from=available_from, available_to=available_to)
    db.session.add(new_room)
    db.session.commit()
    return redirect(url_for('admin_end'))

@app.route('/booked_rooms')
def booked_rooms():
    booked_rooms = Booking.query.all()
    return render_template('booked_rooms.html', booked_rooms=booked_rooms)







@app.route('/rooms/edit/<int:booking_id>', methods=['GET', 'POST'])
def edit_booking(booking_id):
    booking = Booking.query.get(booking_id)

    if request.method == 'POST':
        booking.name = request.form.get('name')
        booking.email = request.form.get('email')
        booking.phone = request.form.get('phone')
        booking.address = request.form.get('address')
        
        db.session.commit()
        return redirect(url_for('admin_end'))

    return render_template('edit_booking.html', booking=booking)


@app.route('/rooms/delete/<int:booking_id>', methods=['GET', 'POST'])
def delete_booking(booking_id):
    booking = Booking.query.get(booking_id)

    if request.method == 'POST':
        db.session.delete(booking)
        db.session.commit()
        return redirect(url_for('admin_end'))

    return render_template('delete_booking.html', booking=booking)




@app.route('/rooms/edit_room/<int:room_id>', methods=['GET', 'POST'])
def edit_room(room_id):
    room = Room.query.get(room_id)

    if request.method == 'POST':
        room.room_number = request.form.get('room_number')
        room.available_from = datetime.strptime(request.form.get('available_from'), '%Y-%m-%dT%H:%M')
        room.available_to = datetime.strptime(request.form.get('available_to'), '%Y-%m-%dT%H:%M')

        new_image = request.files['new_image']
        if new_image:
            filename = secure_filename(new_image.filename)
            new_image.save(os.path.join('static', filename))
            room.image_path = filename

        db.session.commit()
        return redirect(url_for('admin_end'))

    return render_template('edit_room.html', room=room)






# .....................................................AMBULANCE....................................................................
@app.route('/ambulance')
def user_page():
    return render_template('ambulance.html')


@app.route('/call', methods=['POST'])
def call_ambulance():
    name = request.form['name']
    phone = request.form['phone']
    address = request.form['address']
    date = request.form['date']
    ambulance_type = request.form['ambulance-type']

    # Create an instance of AmbulanceOrder
    new_order = AmbulanceOrder(
        name=name, phone=phone, address=address, date=date, ambulance_type=ambulance_type)

    # Add the order to the database
    db.session.add(new_order)
    db.session.commit()

    return redirect('/ambulance')


@app.route('/ambulance_admin')
def admin_page():
    orders = AmbulanceOrder.query.all()
    return render_template('ambulance_admin.html', orders=orders)


@app.route('/edit_ambulance/<int:order_id>', methods=['GET', 'POST'])
def edit_order(order_id):
    order = AmbulanceOrder.query.get_or_404(order_id)

    if request.method == 'POST':
        # Update the attributes of the order
        order.name = request.form['name']
        order.phone = request.form['phone']
        order.address = request.form['address']
        order.date = request.form['date']
        order.ambulance_type = request.form['ambulance-type']

        db.session.commit()
        flash('Order updated successfully!', 'success')
        return redirect('/ambulance_admin')

    return render_template('ambulance_edit.html', order=order)


@app.route('/delete_ambulance/<int:order_id>', methods=['GET', 'POST'])
def delete_ambulance(order_id):
    order = AmbulanceOrder.query.get_or_404(order_id)

    if request.method == 'POST':
        db.session.delete(order)
        db.session.commit()
        flash('Order deleted successfully!', 'success')
        return redirect('/ambulance_admin')

    return render_template('ambulance_delete.html', order=order)


app.run(debug=True)
